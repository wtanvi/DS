#include<stdio.h>
void main()
{
int i,fact=1,n;
printf("enter any value");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
fact=fact*i;
}
printf("the factorial of %d:%d",n,fact);
}
