#include<stdio.h>

int main()
{
	int a=0,b=1,n,i,fibo;
	printf("Enter the number:\n");
	scanf("%d",&n);
	for (i=2;i<n;i++)
	{
	
	fibo=a+b;
	fibo=a;
	a=b;
	b=fibo;	
	printf("%d",fibo);
	}
	
	return 0;
}

