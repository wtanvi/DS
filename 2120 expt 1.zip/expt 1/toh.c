#include<stdio.h>

 void toh1(int n,char source,char dest,char temp);
int count;
 int main()
 {
    int n;
    printf("Enter the number of disk:\n");
    scanf("%d",&n);
    count=0;
    toh1(n,'A','C','B');
    printf("Total no of moves:%d",count);
 }

 void toh1(int n,char source,char dest,char temp)
 {
    if(n>0)
    {
        toh1(n-1,source,temp,dest);
        printf("Move %d from Tower %c to Tower\n");
        count++;
        toh1(n-1,temp,dest,source);
    }
 }